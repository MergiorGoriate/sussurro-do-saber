import{c as s,j as e}from"./index-Q6tQgt-N.js";/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M4 11a9 9 0 0 1 9 9",key:"pv89mb"}],["path",{d:"M4 4a16 16 0 0 1 16 16",key:"k0647b"}],["circle",{cx:"5",cy:"19",r:"1",key:"bfqh0e"}]],a=s("rss",t),d=()=>e.jsx("div",{className:"min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-6",children:e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"inline-flex p-4 bg-orange-100 dark:bg-orange-900/20 rounded-full text-orange-500 mb-6",children:e.jsx(a,{size:48})}),e.jsx("h1",{className:"text-3xl font-black text-slate-900 dark:text-white mb-2",children:"Feed RSS"}),e.jsx("p",{className:"text-slate-500 dark:text-slate-400",children:"Em breve disponível para subscrição."}),e.jsx("div",{className:"mt-8 p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 font-mono text-sm text-slate-600 dark:text-slate-400",children:"https://sussurrosdosaber.pt/feed.xml"})]})});export{d as default};
